package com.uliieumi.customized.policy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizedPolicyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomizedPolicyApplication.class, args);
	}

}
