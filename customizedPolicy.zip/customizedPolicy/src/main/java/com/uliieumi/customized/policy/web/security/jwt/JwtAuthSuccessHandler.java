package com.uliieumi.customized.policy.web.security.jwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uliieumi.customized.policy.web.security.Account;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthSuccessHandler  {
    private final RequestCache requestCache = new HttpSessionRequestCache();

    private final TokenProvider tokenProvider;

    public String authenticationSuccess(HttpServletRequest request, HttpServletResponse response, Account user){
        boolean accessTokenExist = false;
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("accessToken"))
                    accessTokenExist = true;
            }
            if(accessTokenExist) throw new IllegalStateException("이미 로그인 상태입니다.");
        }


        String accessToken = tokenProvider.createAccessToken(user);
        Cookie newAccessTokenCookie = new Cookie("accessToken", accessToken);
        newAccessTokenCookie.setHttpOnly(true);
        newAccessTokenCookie.setMaxAge(3 * 60 * 60);
        newAccessTokenCookie.setPath("/");
        response.addCookie(newAccessTokenCookie);

        clearSession(request);

        SavedRequest savedRequest = requestCache.getRequest(request, response);

        /**
         * prevPage가 존재하는 경우 = 사용자가 직접 /auth/login 경로로 로그인 요청
         * 기존 Session의 prevPage attribute 제거
         */
        String prevPage = (String) request.getSession().getAttribute("prevPage");
        if (prevPage != null) {
            request.getSession().removeAttribute("prevPage");
        }

        // 기본 URI
        String uri = "/";

        /**
         * savedRequest 존재하는 경우 = 인증 권한이 없는 페이지 접근
         * Security Filter가 인터셉트하여 savedRequest에 세션 저장
         */
        if (savedRequest != null) {
            uri = savedRequest.getRedirectUrl();
        } else if (prevPage != null && !prevPage.equals("")) {
            // 회원가입 - 로그인으로 넘어온 경우 "/"로 redirect
            if (prevPage.contains("/auth/join")) {
                uri = "/";
            } else {
                uri = prevPage;
            }
        }

        return uri;
    }

    // 로그인 실패 후 성공 시 남아있는 에러 세션 제거
    protected void clearSession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
        }
    }
}
