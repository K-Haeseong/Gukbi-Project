package com.uliieumi.customized.policy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomizedPolicyApplicationTests {

	@Test
	void contextLoads() {
	}

}
